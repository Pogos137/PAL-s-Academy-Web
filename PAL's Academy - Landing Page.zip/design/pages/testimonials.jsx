// ============================================================
// Testimonials — student & parent reviews
// ============================================================

const TESTIMONIALS = [
  {
    quote: "My daughter went from a 58 to an 82 in SCH4U in one semester. PAL's Academy changed everything.",
    who: "Parent",
    where: "Scarborough",
    audience: "parent",
    subject: "SCH4U",
  },
  {
    quote: "I was failing MCV4U at midterm. Maya broke down vectors in a way my teacher never did — I ended the year with a 91.",
    who: "Grade 12 student",
    where: "Markham",
    audience: "student",
    subject: "MCV4U",
  },
  {
    quote: "Honestly, the consistency is what did it. Same tutor every week, same time. My son stopped dreading Sunday nights.",
    who: "Parent",
    where: "Mississauga",
    audience: "parent",
    subject: "MHF4U",
  },
  {
    quote: "First-year chem at U of T was a wall. Two months with David and I'm actually keeping up. I wish I'd done this in September.",
    who: "First-year university student",
    where: "Toronto",
    audience: "student",
    subject: "CHM135",
  },
  {
    quote: "We tried two other agencies before this one. The difference is the matching — they actually picked a tutor my kid clicks with.",
    who: "Parent",
    where: "Vaughan",
    audience: "parent",
    subject: "ENG4U",
  },
  {
    quote: "I'm shy and didn't think I'd talk much in tutoring. Élise made it feel like a conversation, not an exam. My French went up two grade brackets.",
    who: "Grade 11 student",
    where: "North York",
    audience: "student",
    subject: "FSF3U",
  },
];

function TestimonialCard({ t }) {
  return (
    <figure className="testi-card">
      <Icon name="quote" size={28} strokeWidth={1.5} className="testi-card__mark" />
      <blockquote className="testi-card__quote">{t.quote}</blockquote>
      <figcaption className="testi-card__who">
        <div className="testi-card__name">— {t.who}, {t.where}</div>
        <span className="testi-card__tag">{t.subject}</span>
      </figcaption>
    </figure>
  );
}

function TestimonialsPage() {
  return (
    <React.Fragment>
      <section className="page-hero" data-screen-label="Testimonials hero">
        <div className="container">
          <span className="eyebrow">What families say</span>
          <h1>Real stories. <em>Real grade changes.</em></h1>
          <p className="page-hero__lede">
            Names and identifying details are kept private; courses and grade
            improvements are what families have shared with us, with permission.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="testi-grid">
            {TESTIMONIALS.map((t, i) => (
              <TestimonialCard t={t} key={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <div className="metrics">
            <div className="metric">
              <div className="metric__big">+14<small>pts</small></div>
              <div className="metric__label">Average grade change</div>
              <div className="metric__sub">Across students who stayed at least one semester.</div>
            </div>
            <div className="metric">
              <div className="metric__big">93<small>%</small></div>
              <div className="metric__label">Families that renew</div>
              <div className="metric__sub">Most stick through the school year and beyond.</div>
            </div>
            <div className="metric">
              <div className="metric__big">1–2<small> days</small></div>
              <div className="metric__label">Average response time</div>
              <div className="metric__sub">From consultation form to first call back.</div>
            </div>
          </div>
        </div>
      </section>

      <section className="section page-cta">
        <div className="container page-cta__inner">
          <h2>Your story next?</h2>
          <p>Tell us about the student. We'll be in touch within 1–2 business days.</p>
          <a href="Contact Us.html" className="btn btn-primary btn-lg">
            Book a free consultation
            <Icon name="arrow-right" size={18} />
          </a>
        </div>
      </section>
    </React.Fragment>
  );
}

window.TestimonialsPage = TestimonialsPage;
