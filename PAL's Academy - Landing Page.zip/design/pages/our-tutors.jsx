// ============================================================
// Our Tutors — full tutor profile cards
// ============================================================

function OurTutorsPage() {
  const tutors = window.TUTORS || [];
  return (
    <React.Fragment>
      <section className="page-hero" data-screen-label="Our tutors hero">
        <div className="container">
          <span className="eyebrow">Our tutors</span>
          <h1>Meet the people <em>who'll actually be in your sessions.</em></h1>
          <p className="page-hero__lede">
            Every tutor on this page personally aced the course they teach.
            We've sat in on their sessions. We know who they are.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="tutor-grid tutor-grid--page">
            {tutors.map((t) => (
              <TutorCard tutor={t} key={t.id} expanded showBookBtn />
            ))}
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <div className="vetting">
            <div className="vetting__head">
              <span className="eyebrow">How we vet</span>
              <h2>What "verified" actually means.</h2>
              <p>It isn't a checkbox. It's a small set of things we won't compromise on.</p>
            </div>
            <ul className="vetting__list">
              <li>
                <Icon name="award" size={18} />
                <span><strong>Top of their class.</strong> Every tutor scored in the top of their cohort in the exact course they teach.</span>
              </li>
              <li>
                <Icon name="shield-check" size={18} />
                <span><strong>Police-checked.</strong> Standard background screening before they ever meet a student.</span>
              </li>
              <li>
                <Icon name="message-circle" size={18} />
                <span><strong>We sit in.</strong> Senior staff observe early sessions and give feedback. Nobody is left to figure it out alone.</span>
              </li>
              <li>
                <Icon name="heart-handshake" size={18} />
                <span><strong>Personality fit.</strong> Subject expertise is table stakes — we match on temperament too.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section page-cta">
        <div className="container page-cta__inner">
          <h2>Don't see your subject?</h2>
          <p>Our roster is bigger than this page. Tell us what you need and we'll match you.</p>
          <a href="Contact Us.html" className="btn btn-primary btn-lg">
            Request a tutor
            <Icon name="arrow-right" size={18} />
          </a>
        </div>
      </section>
    </React.Fragment>
  );
}

window.OurTutorsPage = OurTutorsPage;
